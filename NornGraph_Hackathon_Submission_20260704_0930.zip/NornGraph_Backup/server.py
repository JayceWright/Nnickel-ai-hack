"""
server.py — FastAPI бэкенд системы NornGraph.
Запуск: python server.py
"""

import os
import re
import json
import asyncio
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from openai import OpenAI
from neo4j import GraphDatabase
from dotenv import load_dotenv

load_dotenv()

# ─── Конфиг ──────────────────────────────────────────────────────────────────

NEO4J_URI = os.getenv("NEO4J_URI")
NEO4J_USER = os.getenv("NEO4J_USER")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")
ROUTERAI_KEY = os.getenv("ROUTERAI_KEY")
ROUTERAI_BASE_URL = os.getenv("ROUTERAI_BASE_URL", "https://api.routerai.ru/v1")
LLM_MODEL = os.getenv("LLM_MODEL", "deepseek/deepseek-chat")

# ─── Инициализация ────────────────────────────────────────────────────────────

app = FastAPI(title="NornGraph API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

neo4j_driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))

llm_client = OpenAI(
    base_url=ROUTERAI_BASE_URL,
    api_key=ROUTERAI_KEY
)

# ─── Модели данных ────────────────────────────────────────────────────────────

class QueryRequest(BaseModel):
    question: str
    max_hops: int = 2


class UploadStatus:
    """In-memory статус загрузки файлов."""
    _jobs: dict = {}

    @classmethod
    def set(cls, job_id: str, data: dict):
        cls._jobs[job_id] = data

    @classmethod
    def get(cls, job_id: str) -> dict:
        return cls._jobs.get(job_id, {"status": "not_found"})


# ─── Вспомогательные функции ─────────────────────────────────────────────────

def get_graph_context(question: str, max_hops: int = 2) -> str:
    """Извлекает релевантный контекст из Neo4j для GraphRAG."""
    # Ищем ключевые слова в вопросе (простая эвристика)
    keywords = [w for w in re.split(r'\W+', question) if len(w) > 3]

    if not keywords:
        return ""

    # Строим OR-условие для поиска по имени узла
    conditions = " OR ".join([f"toLower(n.name) CONTAINS toLower('{kw}')" for kw in keywords[:5]])

    cypher = f"""
    MATCH (n)
    WHERE {conditions}
    WITH n LIMIT 5
    CALL {{
        WITH n
        MATCH path = (n)-[*1..{max_hops}]-(related)
        RETURN related, relationships(path) as rels
        LIMIT 30
    }}
    RETURN n.name as center, n.label as center_type,
           related.name as related_name, related.label as related_type,
           [r in rels | type(r)] as rel_types
    LIMIT 50
    """

    context_parts = []
    with neo4j_driver.session() as session:
        results = session.run(cypher)
        for record in results:
            context_parts.append(
                f"{record['center']} ({record['center_type']}) "
                f"--[{' -> '.join(record['rel_types'])}]--> "
                f"{record['related_name']} ({record['related_type']})"
            )

    return "\n".join(context_parts) if context_parts else ""


def extract_entities_with_llm(text: str) -> dict:
    """Извлекает сущности и связи из текста через RouterAI."""
    prompt = f"""Ты — эксперт по металлургии никеля и меди. Проанализируй следующий текст и извлеки из него сущности и связи в виде JSON.

Текст:
{text[:4000]}

Верни JSON строго следующей структуры:
{{
  "nodes": [
    {{"id": "уникальный_id", "label": "тип_узла", "name": "название"}}
  ],
  "edges": [
    {{"source": "id_источника", "target": "id_цели", "type": "тип_связи"}}
  ]
}}

Допустимые типы узлов: Material, Process, Equipment, Property, Experiment, Expert, Publication, Organization, Condition
Допустимые типы связей: uses, applies, produces_output, operated_by, condition_of, authored_by, affiliated_with, describes, contradicts

Только JSON, без пояснений."""

    response = llm_client.chat.completions.create(
        model=LLM_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1,
        max_tokens=2000
    )

    raw = response.choices[0].message.content
    json_match = re.search(r'\{[\s\S]*\}', raw)
    if not json_match:
        return {"nodes": [], "edges": []}

    try:
        return json.loads(json_match.group(0))
    except json.JSONDecodeError:
        return {"nodes": [], "edges": []}


def merge_entities_to_neo4j(graph_data: dict) -> dict:
    """Сохраняет извлечённые сущности в Neo4j."""
    nodes = graph_data.get("nodes", [])
    edges = graph_data.get("edges", [])
    created_nodes = []
    created_edges = []

    with neo4j_driver.session() as session:
        for node in nodes:
            node_id = str(node.get("id", "")).strip()
            label = node.get("label", "Unknown").strip()
            name = node.get("name", node_id).strip()
            if not node_id or not name:
                continue

            session.run(
                f"MERGE (n:{label} {{id: $id}}) SET n.name = $name, n.label = $label",
                {"id": node_id, "name": name, "label": label}
            )
            created_nodes.append({"id": node_id, "label": label, "name": name})

        for edge in edges:
            src = str(edge.get("source", "")).strip()
            tgt = str(edge.get("target", "")).strip()
            rel_type = edge.get("type", "RELATED").strip().upper().replace(" ", "_")
            if not src or not tgt:
                continue

            session.run(
                f"MATCH (a {{id: $src}}), (b {{id: $tgt}}) MERGE (a)-[r:{rel_type}]->(b)",
                {"src": src, "tgt": tgt}
            )
            created_edges.append({"source": src, "target": tgt, "type": rel_type})

    return {"nodes": created_nodes, "edges": created_edges}


# ─── API Эндпоинты ────────────────────────────────────────────────────────────

@app.get("/api/health")
def health_check():
    """Проверка работоспособности сервиса."""
    try:
        neo4j_driver.verify_connectivity()
        return {"status": "ok", "neo4j": "connected", "model": LLM_MODEL}
    except Exception as e:
        raise HTTPException(status_code=503, detail=str(e))


@app.get("/api/stats")
def get_stats():
    """Статистика графа: количество узлов и рёбер по типам."""
    with neo4j_driver.session() as session:
        node_counts = {}
        for label in ["Material", "Process", "Equipment", "Property",
                      "Experiment", "Expert", "Publication", "Organization", "Condition"]:
            result = session.run(f"MATCH (n:{label}) RETURN count(n) as cnt")
            node_counts[label] = result.single()["cnt"]

        total_edges = session.run("MATCH ()-[r]->() RETURN count(r) as cnt").single()["cnt"]
        contradicts = session.run("MATCH ()-[r:CONTRADICTS]->() RETURN count(r) as cnt").single()["cnt"]

    return {
        "nodes": node_counts,
        "total_nodes": sum(node_counts.values()),
        "total_edges": total_edges,
        "contradictions": contradicts
    }


@app.get("/api/graph")
def get_graph(limit: int = 500):
    """Выгружает граф в формате для vis-network.js."""
    cypher = f"""
    MATCH (n)
    WITH n LIMIT {limit}
    OPTIONAL MATCH (n)-[r]->(m)
    WHERE m IS NOT NULL
    RETURN collect(DISTINCT {{
        id: n.id, label: n.label, name: n.name, value: n.value
    }}) as nodes,
    collect(DISTINCT {{
        from: n.id, to: m.id, type: type(r), reason: r.reason
    }}) as edges
    """

    nodes_map = {}
    edges_list = []

    with neo4j_driver.session() as session:
        # Получаем все узлы
        all_nodes = session.run("MATCH (n) RETURN properties(n).id as id, n.label as label, n.name as name, n.value as value LIMIT $limit", {"limit": limit})
        for record in all_nodes:
            node_id = record["id"]
            if node_id:
                nodes_map[node_id] = {
                    "id": node_id,
                    "label": record["name"] or node_id,
                    "group": record["label"] or "Unknown",
                    "title": f"{record['label']}: {record['name']}" + (f"\nValue: {record['value']}" if record["value"] else "")
                }

        # Получаем все рёбра
        all_edges = session.run("MATCH (a)-[r]->(b) WHERE properties(a).id IS NOT NULL AND properties(b).id IS NOT NULL RETURN properties(a).id as from, properties(b).id as to, type(r) as type, r.reason as reason LIMIT 1000")
        for record in all_edges:
            edge = {
                "from": record["from"],
                "to": record["to"],
                "label": record["type"].lower(),
                "arrows": "to"
            }
            if record["type"] == "CONTRADICTS":
                edge["color"] = {"color": "#ff4444", "highlight": "#ff0000"}
                edge["dashes"] = True
                edge["title"] = record["reason"] or "Противоречие"
            edges_list.append(edge)

    return {
        "nodes": list(nodes_map.values()),
        "edges": edges_list
    }


@app.post("/api/query")
async def query_graph(request: QueryRequest):
    """GraphRAG: поиск в Neo4j + генерация ответа через RouterAI."""
    if not request.question.strip():
        raise HTTPException(status_code=400, detail="Вопрос не может быть пустым")

    # Получаем контекст из графа
    context = get_graph_context(request.question, request.max_hops)

    # Формируем промпт
    system_prompt = (
        "Ты — интеллектуальный ассистент поисково-аналитической системы NornGraph по металлургии никеля, меди и платиноидов. "
        "Твоя задача — отвечать на вопросы пользователя на основе предоставленного контекста из графа знаний Neo4j. "
        "Правила ответов:\n"
        "1. Если пользователь просто приветствует тебя (например, 'привет', 'здравствуй') или спрашивает 'кто ты', вежливо поприветствуй его и расскажи, что ты ассистент NornGraph, помогающий анализировать связи материалов и процессов на основе графовой базы данных.\n"
        "2. Отвечай строго на основе предоставленного контекста из базы знаний. Указывай конкретные сущности и связи.\n"
        "3. Если контекст пуст, но вопрос касается металлургии никеля/меди/процессов, ответь на основе своих общих знаний, но обязательно начни ответ с фразы: 'В текущем графе знаний точных данных не обнаружено, но на основе общих металлургических данных...'."
        "4. Если данных недостаточно — честно об этом скажи. Отвечай на русском языке."
    )

    user_prompt = f"""Контекст из базы знаний Neo4j (граф связей):
{context if context else "--- ДАННЫЕ В ГРАФЕ НЕ НАЙДЕНЫ ---"}

Вопрос: {request.question}

Ответь согласно правилам."""


    response = llm_client.chat.completions.create(
        model=LLM_MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        temperature=0.3,
        max_tokens=1500
    )

    answer = response.choices[0].message.content

    return {
        "answer": answer,
        "context_used": bool(context),
        "context_preview": context[:500] if context else None
    }


@app.post("/api/upload")
async def upload_document(background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    """Загружает новый документ и асинхронно расширяет граф."""
    import uuid
    job_id = str(uuid.uuid4())[:8]

    # Читаем файл
    content = await file.read()

    # Определяем тип и декодируем
    if file.filename.endswith(".pdf"):
        try:
            import PyPDF2
            import io
            pdf_reader = PyPDF2.PdfReader(io.BytesIO(content))
            text = " ".join(page.extract_text() or "" for page in pdf_reader.pages)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Ошибка чтения PDF: {e}")
    else:
        try:
            text = content.decode("utf-8")
        except UnicodeDecodeError:
            text = content.decode("cp1251", errors="ignore")

    if len(text.strip()) < 100:
        raise HTTPException(status_code=400, detail="Файл слишком мал или пуст")

    UploadStatus.set(job_id, {"status": "processing", "filename": file.filename})

    # Запускаем обработку в фоне
    background_tasks.add_task(process_document_background, job_id, text, file.filename)

    return {"job_id": job_id, "status": "processing", "filename": file.filename}


async def process_document_background(job_id: str, text: str, filename: str):
    """Фоновая задача: извлечение сущностей и сохранение в Neo4j."""
    try:
        graph_data = extract_entities_with_llm(text)
        result = merge_entities_to_neo4j(graph_data)
        UploadStatus.set(job_id, {
            "status": "done",
            "filename": filename,
            "nodes_created": len(result["nodes"]),
            "edges_created": len(result["edges"]),
            "new_nodes": result["nodes"],
            "new_edges": result["edges"]
        })
    except Exception as e:
        UploadStatus.set(job_id, {"status": "error", "filename": filename, "error": str(e)})


@app.get("/api/upload/status/{job_id}")
def get_upload_status(job_id: str):
    """Проверяет статус обработки загруженного документа."""
    return UploadStatus.get(job_id)


@app.get("/api/analytics")
def get_analytics():
    """Аналитика: противоречия и пробелы в данных."""
    with neo4j_driver.session() as session:
        # Противоречия
        contradictions = []
        result = session.run(
            "MATCH (a)-[r:CONTRADICTS]->(b) "
            "RETURN a.name as from_name, b.name as to_name, r.reason as reason LIMIT 20"
        )
        for record in result:
            contradictions.append({
                "from": record["from_name"],
                "to": record["to_name"],
                "reason": record["reason"] or "Нет описания"
            })

        # Пробелы (материалы без связанных процессов)
        gaps = []
        result = session.run(
            "MATCH (m:Material) WHERE NOT (m)-[:USES|:APPLIES|:PRODUCES_OUTPUT]-() "
            "RETURN m.name as name LIMIT 10"
        )
        for record in result:
            gaps.append({"type": "isolated_material", "name": record["name"]})

    return {
        "contradictions": contradictions,
        "gaps": gaps,
        "total_contradictions": len(contradictions),
        "total_gaps": len(gaps)
    }


# ─── Статика ──────────────────────────────────────────────────────────────────

static_dir = Path(__file__).parent / "static"
static_dir.mkdir(exist_ok=True)

app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


@app.get("/")
def serve_ui():
    index = static_dir / "index.html"
    if index.exists():
        return FileResponse(str(index))
    return {"message": "NornGraph API работает. UI файлы не найдены."}


# ─── Запуск ───────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    print("🚀 Запуск NornGraph API сервера...")
    print(f"   Neo4j: {NEO4J_URI}")
    print(f"   LLM:   {LLM_MODEL} via RouterAI")
    print(f"   UI:    http://localhost:8001")
    uvicorn.run(app, host="0.0.0.0", port=8001, reload=False)

