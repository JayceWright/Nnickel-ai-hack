// ─── Config ───────────────────────────────────────────────────────────────────
const API = '';  // пустой = тот же сервер

// Цвета по типу узла
const NODE_COLORS = {
  Material:     { background: '#1e3a5f', border: '#60a5fa', highlight: { background: '#2a4f7c', border: '#93c5fd' } },
  Process:      { background: '#064e3b', border: '#34d399', highlight: { background: '#065f46', border: '#6ee7b7' } },
  Experiment:   { background: '#3d2b00', border: '#f59e0b', highlight: { background: '#4d3600', border: '#fcd34d' } },
  Equipment:    { background: '#2e1065', border: '#a78bfa', highlight: { background: '#3b0764', border: '#c4b5fd' } },
  Property:     { background: '#450a0a', border: '#f87171', highlight: { background: '#5a0e0e', border: '#fca5a5' } },
  Expert:       { background: '#431407', border: '#fb923c', highlight: { background: '#5a1a07', border: '#fdba74' } },
  Publication:  { background: '#1e293b', border: '#94a3b8', highlight: { background: '#273549', border: '#cbd5e1' } },
  Organization: { background: '#0f172a', border: '#7dd3fc', highlight: { background: '#1e2e44', border: '#bae6fd' } },
  Condition:    { background: '#1a1a2e', border: '#818cf8', highlight: { background: '#252545', border: '#a5b4fc' } },
};

const DEFAULT_COLOR = { background: '#1a2236', border: '#3b82f6', highlight: { background: '#1e2a40', border: '#60a5fa' } };

// ─── State ────────────────────────────────────────────────────────────────────
let network = null;
let allNodes = [];
let allEdges = [];
let physicsEnabled = true;

// ─── Init ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await checkHealth();
  await loadStats();
  await loadGraph();
  switchPanel('graph');
});

// ─── Health Check ─────────────────────────────────────────────────────────────
async function checkHealth() {
  try {
    const res = await fetch(`${API}/api/health`);
    const dot = document.getElementById('status-dot');
    if (res.ok) {
      dot.classList.add('connected');
      dot.title = 'Подключено к Neo4j';
    } else {
      dot.classList.add('error');
      dot.title = 'Ошибка подключения';
    }
  } catch {
    document.getElementById('status-dot').classList.add('error');
  }
}

// ─── Stats ────────────────────────────────────────────────────────────────────
async function loadStats() {
  try {
    const data = await fetch(`${API}/api/stats`).then(r => r.json());
    document.getElementById('stat-nodes').textContent = `${data.total_nodes} узлов`;
    document.getElementById('stat-edges').textContent = `${data.total_edges} связей`;
    document.getElementById('stat-contradictions').textContent = `${data.contradictions} противоречий`;
  } catch (e) {
    console.warn('Stats error:', e);
  }
}

// ─── Graph ────────────────────────────────────────────────────────────────────
async function loadGraph() {
  try {
    const data = await fetch(`${API}/api/graph?limit=300`).then(r => r.json());

    allNodes = data.nodes.map(n => ({
      id: n.id,
      label: truncate(n.label, 22),
      title: n.title || n.label,
      group: n.group,
      color: NODE_COLORS[n.group] || DEFAULT_COLOR,
      font: { color: '#e2e8f0', size: 11, face: 'Inter' },
      size: getNodeSize(n.group),
      borderWidth: 1.5,
      shape: getNodeShape(n.group),
    }));

    allEdges = data.edges.map((e, i) => ({
      id: i,
      from: e.from,
      to: e.to,
      label: e.label,
      title: e.title || e.label,
      color: e.color || { color: '#2a3f5f', highlight: '#3b82f6' },
      dashes: e.dashes || false,
      arrows: 'to',
      font: { color: '#4a6080', size: 9, align: 'middle' },
      width: e.label === 'contradicts' ? 2 : 1,
    }));

    renderGraph(allNodes, allEdges);
  } catch (e) {
    console.error('Graph load error:', e);
  }
}

function getNodeSize(group) {
  const sizes = { Experiment: 20, Material: 16, Process: 15, Expert: 13, Publication: 11 };
  return sizes[group] || 12;
}

function getNodeShape(group) {
  const shapes = {
    Experiment: 'dot', Material: 'diamond', Process: 'box',
    Expert: 'ellipse', Publication: 'triangleDown', Equipment: 'star',
    Property: 'dot', Organization: 'ellipse', Condition: 'dot'
  };
  return shapes[group] || 'dot';
}

function truncate(str, max) {
  if (!str) return '?';
  return str.length > max ? str.slice(0, max) + '…' : str;
}

function renderGraph(nodes, edges) {
  const container = document.getElementById('graph-container');
  const dataset = {
    nodes: new vis.DataSet(nodes),
    edges: new vis.DataSet(edges)
  };

  const options = {
    physics: {
      enabled: physicsEnabled,
      solver: 'barnesHut',
      barnesHut: { gravitationalConstant: -2000, centralGravity: 0.3, springLength: 95, springConstant: 0.04, damping: 0.09 },
      stabilization: false
    },
    interaction: {
      hover: true,
      tooltipDelay: 200,
      navigationButtons: false,
      zoomView: true,
    },
    edges: {
      smooth: { type: 'continuous', roundness: 0.2 },
    },
    nodes: {
      scaling: { min: 8, max: 25 }
    }
  };

  if (network) network.destroy();
  network = new vis.Network(container, dataset, options);

  // Клик по узлу → показываем детали
  network.on('click', params => {
    if (params.nodes.length > 0) {
      const nodeId = params.nodes[0];
      const node = nodes.find(n => n.id === nodeId);
      if (node) showNodeDetail(node);
    } else {
      hideNodeDetail();
    }
  });

  // Подсветка новых узлов (если есть)
  network.on('stabilizationIterationsDone', () => {
    network.setOptions({ physics: { enabled: false } });
    physicsEnabled = false;
    network.fit();
  });

}

function showNodeDetail(node) {
  const panel = document.getElementById('node-detail');
  const content = document.getElementById('node-detail-content');
  panel.style.display = 'block';
  content.innerHTML = `
    <div class="detail-type">${node.group}</div>
    <div class="detail-name">${node.title || node.label}</div>
  `;
}

function hideNodeDetail() {
  document.getElementById('node-detail').style.display = 'none';
}

function fitGraph() {
  if (network) network.fit({ animation: { duration: 500, easingFunction: 'easeInOutQuad' } });
}

function togglePhysics() {
  physicsEnabled = !physicsEnabled;
  if (network) network.setOptions({ physics: { enabled: physicsEnabled } });
}

function filterGraph() {
  const type = document.getElementById('filter-type').value;
  if (!type) {
    renderGraph(allNodes, allEdges);
    return;
  }
  const filtered = allNodes.filter(n => n.group === type);
  const filteredIds = new Set(filtered.map(n => n.id));
  const filteredEdges = allEdges.filter(e => filteredIds.has(e.from) && filteredIds.has(e.to));
  renderGraph(filtered, filteredEdges);
}

// ─── Panel Switching ──────────────────────────────────────────────────────────
function switchPanel(name) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));

  document.getElementById(`panel-${name}`).classList.add('active');
  document.querySelector(`[data-panel="${name}"]`).classList.add('active');

  if (name === 'graph' && network) {
    // Принудительно заставляем vis-network пересчитать размеры холста
    setTimeout(() => {
      network.setSize('100%', '100%');
      network.redraw();
      network.fit();
    }, 50);
  }

  if (name === 'analytics') loadAnalytics();
}


// ─── Q&A ──────────────────────────────────────────────────────────────────────
function fillQuestion(text) {
  document.getElementById('qa-input').value = text;
  sendQuestion();
}

function handleQAKeydown(event) {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    sendQuestion();
  }
}

async function sendQuestion() {
  const input = document.getElementById('qa-input');
  const question = input.value.trim();
  if (!question) return;

  const btn = document.getElementById('send-btn');
  btn.disabled = true;
  input.value = '';

  // Убираем welcome screen
  const welcome = document.querySelector('.chat-welcome');
  if (welcome) welcome.remove();

  // Добавляем сообщение пользователя
  addChatMessage(question, 'user');

  // Добавляем загрузчик
  const loadingId = 'loading-' + Date.now();
  addChatMessage('', 'assistant', loadingId, true);

  try {
    const res = await fetch(`${API}/api/query`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, max_hops: 2 })
    });
    const data = await res.json();

    // Заменяем загрузчик ответом
    const loading = document.getElementById(loadingId);
    if (loading) {
      const bubble = loading.querySelector('.chat-bubble');
      bubble.classList.remove('loading');
      bubble.textContent = data.answer;
    }
  } catch (e) {
    const loading = document.getElementById(loadingId);
    if (loading) {
      const bubble = loading.querySelector('.chat-bubble');
      bubble.classList.remove('loading');
      bubble.textContent = 'Ошибка запроса. Проверьте подключение к серверу.';
      bubble.style.borderColor = 'rgba(239,68,68,0.4)';
    }
  }

  btn.disabled = false;
  input.focus();
}

function addChatMessage(text, role, id = null, isLoading = false) {
  const container = document.getElementById('chat-messages');
  const div = document.createElement('div');
  div.className = `chat-message ${role}`;
  if (id) div.id = id;

  const emoji = role === 'user' ? '👤' : '🤖';
  div.innerHTML = `
    <div class="chat-avatar">${emoji}</div>
    <div class="chat-bubble ${isLoading ? 'loading' : ''}">${text || (isLoading ? 'Анализирую граф знаний...' : '')}</div>
  `;

  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

// ─── Analytics ────────────────────────────────────────────────────────────────
async function loadAnalytics() {
  try {
    const data = await fetch(`${API}/api/analytics`).then(r => r.json());

    const cList = document.getElementById('contradictions-list');
    cList.innerHTML = '';
    if (data.contradictions.length === 0) {
      cList.innerHTML = '<div class="empty-state">Противоречий не найдено</div>';
    } else {
      data.contradictions.forEach(c => {
        const item = document.createElement('div');
        item.className = 'contradiction-item';
        item.innerHTML = `
          <div class="contradiction-nodes"><strong>${c.from}</strong> ↔ <strong>${c.to}</strong></div>
          <div class="contradiction-reason">⚠ ${c.reason}</div>
        `;
        cList.appendChild(item);
      });
    }

    const gList = document.getElementById('gaps-list');
    gList.innerHTML = '';
    if (data.gaps.length === 0) {
      gList.innerHTML = '<div class="empty-state">Изолированных узлов не найдено</div>';
    } else {
      data.gaps.forEach(g => {
        const item = document.createElement('div');
        item.className = 'gap-item';
        item.textContent = `📦 ${g.name}`;
        gList.appendChild(item);
      });
    }
  } catch (e) {
    console.error('Analytics error:', e);
  }
}

// ─── Upload ───────────────────────────────────────────────────────────────────
function handleDragover(e) {
  e.preventDefault();
  document.getElementById('upload-zone').classList.add('dragging');
}

function handleDragleave() {
  document.getElementById('upload-zone').classList.remove('dragging');
}

function handleDrop(e) {
  e.preventDefault();
  document.getElementById('upload-zone').classList.remove('dragging');
  const file = e.dataTransfer.files[0];
  if (file) uploadFile(file);
}

function handleFileSelect(e) {
  const file = e.target.files[0];
  if (file) uploadFile(file);
}

async function uploadFile(file) {
  const statusDiv  = document.getElementById('upload-status');
  const statusText = document.getElementById('upload-status-text');
  const progressBar = document.getElementById('progress-bar');
  const resultDiv  = document.getElementById('upload-result');

  statusDiv.style.display = 'block';
  resultDiv.innerHTML = '';
  progressBar.style.width = '20%';
  statusText.textContent = `📄 Загрузка файла: ${file.name}...`;

  const formData = new FormData();
  formData.append('file', file);

  try {
    const res = await fetch(`${API}/api/upload`, { method: 'POST', body: formData });
    if (!res.ok) throw new Error((await res.json()).detail);

    const { job_id } = await res.json();
    progressBar.style.width = '50%';
    statusText.textContent = '🔍 Извлечение сущностей через LLM...';

    // Polling статуса
    await pollUploadStatus(job_id, progressBar, statusText, resultDiv);

    // Обновляем граф и статистику
    await loadGraph();
    await loadStats();
  } catch (e) {
    statusText.textContent = `❌ Ошибка: ${e.message}`;
    progressBar.style.background = '#ef4444';
  }
}

async function pollUploadStatus(jobId, progressBar, statusText, resultDiv) {
  for (let i = 0; i < 30; i++) {
    await new Promise(r => setTimeout(r, 2000));

    const status = await fetch(`${API}/api/upload/status/${jobId}`).then(r => r.json());

    if (status.status === 'done') {
      progressBar.style.width = '100%';
      statusText.textContent = `✅ Обработка завершена!`;
      resultDiv.innerHTML = `
        <strong>Добавлено в граф:</strong><br>
        🔵 Новых узлов: <strong>${status.nodes_created}</strong><br>
        🔗 Новых связей: <strong>${status.edges_created}</strong><br><br>
        <strong>Созданные узлы:</strong><br>
        ${status.new_nodes.map(n =>
          `<span class="result-node" style="background: rgba(59,130,246,0.15); border: 1px solid rgba(59,130,246,0.4); color: #60a5fa;">${n.label}: ${n.name}</span>`
        ).join('')}
      `;
      return;
    }

    if (status.status === 'error') {
      throw new Error(status.error || 'Неизвестная ошибка');
    }

    progressBar.style.width = Math.min(50 + i * 2, 90) + '%';
  }
  throw new Error('Таймаут обработки');
}
